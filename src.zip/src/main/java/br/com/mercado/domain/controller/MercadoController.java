package br.com.mercado.domain.controller;

import br.com.mercado.domain.model.Mercado;
import br.com.mercado.domain.service.MercadoSevice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/mercado")
public class MercadoController {

    @Autowired
    MercadoSevice mercadoSevice;

    @GetMapping
    public List<Mercado> getAll() {return mercadoSevice.getAll();
    }

    //TODO Create

    //TODO Read

    //TODO Update

    //TODO Delete

}
