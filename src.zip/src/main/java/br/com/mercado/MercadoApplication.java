package br.com.mercado;

import br.com.mercado.domain.model.*;
import br.com.mercado.domain.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

@SpringBootApplication
public class MercadoApplication {

	public static void main(String[] args) {
		SpringApplication.run(MercadoApplication.class, args);
	}

	@Bean
	CommandLineRunner initDatabase(@Autowired
			CategoriaRepository categoriaRepository
	) {
		return args -> {
			// Criando três categorias
			Categoria categoria1 = Categoria.builder()
					.nome("Alimentos")
					.build();

			Categoria categoria2 = Categoria.builder()
					.nome("Bebidas")
					.build();

			Categoria categoria3 = Categoria.builder()
					.nome("Limpeza")
					.build();

			// Salvando as categorias no banco
			categoriaRepository.saveAll(Arrays.asList(categoria1, categoria2, categoria3));

			System.out.println("Categorias salvas com sucesso!");

		};

	}


	CommandLineRunner initDatabaseFornecedor(@Autowired
								   FornecedorRepository fornecedorRepository
	) {
		return args -> {

			Fornecedor fornecedor1 = Fornecedor.builder()
					.nome("Fornecedor 1")
					.cnpj("12345678901234")
					.build();
			Fornecedor fornecedor2 = Fornecedor.builder()
					.nome("Fornecedor 2")
					.cnpj("12345678901234")
					.build();
			Fornecedor fornecedor3 = Fornecedor.builder()
					.nome("Fornecedor 3")
					.cnpj("12345678901234")
					.build();
			fornecedorRepository.saveAll(Arrays.asList(fornecedor1, fornecedor2, fornecedor3));
			System.out.println("Fornecedores salvos com sucesso!");
		};
	}


	CommandLineRunner initDatabaseFuncionario(@Autowired
								   FuncionarioRepository funcionarioRepository
	) {
		return args -> {

			Funcionario funcionario1 = Funcionario.builder()
					.nome("Maria")
					.cargo("Ajudante")
					.salario(1000.0)
					.build();
			Funcionario funcionario2 = Funcionario.builder()
					.nome("João")
					.cargo("Gerente")
					.salario(2000.0)
					.build();
			Funcionario funcionario3 = Funcionario.builder()
					.nome("José")
					.cargo("Caixa")
					.salario(1500.0)
					.build();

			funcionarioRepository.saveAll(Arrays.asList(funcionario1, funcionario2, funcionario3));
			System.out.println("Fornecedores salvos com sucesso!");
		};
	}


	CommandLineRunner initDatabaseMercado(@Autowired
								   MercadoRepository mercadoRepository
	) {
		return args -> {

			Mercado mercado1 = Mercado.builder()
					.nome("Mercado do João")
					.endereco("Rua Silva")
					.cnpj("12345678901234")
					.build();
			Mercado mercado2 = Mercado.builder()
					.nome("Mercado do José")
					.endereco("Rua Silva")
					.cnpj("12345678901234")
					.build();
			Mercado mercado3 = Mercado.builder()
					.nome("Mercado da Maria")
					.endereco("Rua Silva")
					.cnpj("12345678901234")
					.build();

			mercadoRepository.saveAll(Arrays.asList(mercado1, mercado2, mercado3));
			System.out.println("Mercados salvos com sucesso!");
		};
	}

		CommandLineRunner initDatabaseProduto(@Autowired
									   ProdutoRepository produtoRepository

		) {
			return args -> {

				Produto produto1 = Produto.builder()
						.nome("Arroz")
						.preco(30.00)
						.build();
				Produto produto2 = Produto.builder()
						.nome("Feijão")
						.preco(8.00)
						.build();
				Produto produto3 = Produto.builder()
						.nome("Macarrão")
						.preco(5.00)
						.build();

				produtoRepository.saveAll(Arrays.asList(produto1, produto2, produto3));
				System.out.println("Produtos salvos com sucesso!");
			};
		}
}
